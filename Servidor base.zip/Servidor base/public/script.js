window.addEventListener("load", init)

async function init () {
    
    console.log("Hola inicial")
}